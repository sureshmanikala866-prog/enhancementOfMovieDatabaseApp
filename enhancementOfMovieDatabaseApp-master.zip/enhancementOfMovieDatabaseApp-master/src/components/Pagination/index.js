import './index.css'

const Pagination = props => {
  const {page, setPage} = props

  const onClickPrev = () => {
    if (page > 1) {
      setPage(page - 1)
    }
  }

  const onClickNext = () => {
    setPage(page + 1)
  }

  return (
    <div className="pagination">
      <button type="button" onClick={onClickPrev} disabled={page === 1}>
        Prev
      </button>

      <p>{page}</p>

      <button type="button" onClick={onClickNext}>
        Next
      </button>
    </div>
  )
}

export default Pagination
