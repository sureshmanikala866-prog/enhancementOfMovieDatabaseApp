import {NavLink, useHistory} from 'react-router-dom'
import {useState} from 'react'
import './index.css'

const Navbar = () => {
  const [search, setSearch] = useState('')
  const history = useHistory()

  const onSearch = () => {
    if (search.trim() !== '') {
      history.push(`/search/${search}`)
    }
  }

  return (
    <nav className="navbar">
      <h1 className="logo">movieDB</h1>

      <div className="nav-links">
        <NavLink to="/">Popular</NavLink>
        <NavLink to="/top-rated">Top Rated</NavLink>
        <NavLink to="/upcoming">Upcoming</NavLink>
      </div>

      <div className="search-box">
        <input
          type="text"
          placeholder="Search Movie"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <button type="button" onClick={onSearch}>
          Search
        </button>
      </div>
    </nav>
  )
}
export default Navbar
