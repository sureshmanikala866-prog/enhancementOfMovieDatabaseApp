import './index.css'

const IMAGE_URL = 'https://image.tmdb.org/t/p/w500'

const CastCard = props => {
  const {cast} = props
  return (
    <div className="cast-card">
      <img
        src={
          cast.profile_path
            ? `${IMAGE_URL}${cast.profile_path}`
            : 'https://via.placeholder.com/300'
        }
        alt={cast.original_name}
        className="cast-image"
      />
      <h4>{cast.original_name}</h4>
      <p>{cast.character}</p>
    </div>
  )
}
export default CastCard
