import {Link} from 'react-router-dom'
import './index.css'

const IMAGE_URL = 'https://image.tmdb.org/t/p/w500'

const MovieCard = props => {
  const {movie} = props

  return (
    <div className="movie-card">
      <img
        src={
          movie.poster_path
            ? `${IMAGE_URL}${movie.poster_path}`
            : 'https://via.placeholder.com/500x750'
        }
        alt={movie.title}
        className="poster"
      />
      <h3>{movie.title}</h3>
      <p>Rating: {movie.vote_average}</p>
      <Link to={`/movie/${movie.id}`}>
        <button type="button">View Details</button>
      </Link>
    </div>
  )
}
export default MovieCard
