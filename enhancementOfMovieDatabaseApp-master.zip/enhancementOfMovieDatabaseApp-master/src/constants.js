export const API_KEY = '80716c75206a523f5fe555b0549e5aa2'
export const IMAGE_URL = 'https://image.tmdb.org/t/p/w500'
