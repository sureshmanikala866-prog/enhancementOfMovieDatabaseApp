import {useState, useEffect} from 'react'
import {useParams} from 'react-router-dom'

import Navbar from '../../components/Navbar'
import MovieCard from '../../components/MovieCard'
import Pagination from '../../components/Pagination'

import {API_KEY} from '../../constants'
import '../Popular/index.css'

const apiStatusConstants = {
  initial: 'INITIAL',
  inProgress: 'IN_PROGRESS',
  success: 'SUCCESS',
  failure: 'FAILURE',
}

const SearchResults = () => {
  const {query} = useParams()

  const [movies, setMovies] = useState([])
  const [apiStatus, setApiStatus] = useState(apiStatusConstants.initial)
  const [page, setPage] = useState(1)

  const getMovies = async () => {
    setApiStatus(apiStatusConstants.inProgress)

    const url = `https://api.themoviedb.org/3/search/movie?api_key=${API_KEY}&language=en-US&query=${query}&page=${page}`

    try {
      const response = await fetch(url)

      if (!response.ok) {
        throw new Error('API request failed')
      }

      const data = await response.json()

      setMovies(data.results || [])
      setApiStatus(apiStatusConstants.success)
    } catch (error) {
      setApiStatus(apiStatusConstants.failure)
    }
  }

  useEffect(() => {
    getMovies()
    // eslint-disable-next-line
  }, [query, page])

  const renderLoadingView = () => <h1>Loading...</h1>

  const renderSuccessView = () => {
    if (movies.length === 0) {
      return <h1>No Movies Found</h1>
    }

    return (
      <>
        <h1
          style={{
            paddingLeft: '20px',
          }}
        >
          Search Results
        </h1>

        <div className="movies-container">
          {movies.map(movie => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>

        <Pagination page={page} setPage={setPage} />
      </>
    )
  }

  const renderFailureView = () => (
    <div>
      <h1>Something went wrong</h1>
      <button type="button" onClick={getMovies}>
        Retry
      </button>
    </div>
  )

  const renderMoviesView = () => {
    switch (apiStatus) {
      case apiStatusConstants.inProgress:
        return renderLoadingView()

      case apiStatusConstants.success:
        return renderSuccessView()

      case apiStatusConstants.failure:
        return renderFailureView()

      default:
        return null
    }
  }

  return (
    <>
      <Navbar />
      {renderMoviesView()}
    </>
  )
}

export default SearchResults
