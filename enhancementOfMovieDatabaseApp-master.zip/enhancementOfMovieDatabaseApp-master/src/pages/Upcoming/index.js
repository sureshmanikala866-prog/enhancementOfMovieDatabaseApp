import React from 'react'

import Navbar from '../../components/Navbar'
import MovieCard from '../../components/MovieCard'
import Pagination from '../../components/Pagination'

import {API_KEY} from '../../constants'

import '../Popular/index.css'

const apiStatusConstants = {
  initial: 'INITIAL',
  inProgress: 'IN_PROGRESS',
  success: 'SUCCESS',
  failure: 'FAILURE',
}

class Upcoming extends React.Component {
  state = {
    movies: [],
    apiStatus: apiStatusConstants.initial,
    page: 1,
  }

  componentDidMount() {
    this.getMovies()
  }

  componentDidUpdate(prevProps, prevState) {
    const {page} = this.state

    if (prevState.page !== page) {
      this.getMovies()
    }
  }

  getMovies = async () => {
    this.setState({
      apiStatus: apiStatusConstants.inProgress,
    })

    const {page} = this.state

    const url = `https://api.themoviedb.org/3/movie/upcoming?api_key=${API_KEY}&page=${page}`

    try {
      const response = await fetch(url)
      const data = await response.json()

      this.setState({
        movies: data.results,
        apiStatus: apiStatusConstants.success,
      })
    } catch (error) {
      this.setState({
        apiStatus: apiStatusConstants.failure,
      })
    }
  }

  updatePage = newPage => {
    this.setState({
      page: newPage,
    })
  }

  renderLoadingView = () => <h1>Loading...</h1>

  renderSuccessView = () => {
    const {movies} = this.state

    return (
      <div className="movies-container">
        {movies.map(movie => (
          <MovieCard key={movie.id} movie={movie} />
        ))}
      </div>
    )
  }

  renderFailureView = () => (
    <div>
      <h1>Something went wrong</h1>
      <button type="button" onClick={this.getMovies}>
        Retry
      </button>
    </div>
  )

  renderMoviesView = () => {
    const {apiStatus} = this.state

    switch (apiStatus) {
      case apiStatusConstants.inProgress:
        return this.renderLoadingView()

      case apiStatusConstants.success:
        return this.renderSuccessView()

      case apiStatusConstants.failure:
        return this.renderFailureView()

      default:
        return null
    }
  }

  render() {
    const {page} = this.state

    return (
      <>
        <Navbar />

        {this.renderMoviesView()}

        <Pagination page={page} setPage={this.updatePage} />
      </>
    )
  }
}

export default Upcoming
