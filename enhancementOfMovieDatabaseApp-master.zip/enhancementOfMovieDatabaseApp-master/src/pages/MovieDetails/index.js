import {useEffect, useState} from 'react'
import {useParams} from 'react-router-dom'

import Navbar from '../../components/Navbar'
import CastCard from '../../components/CastCard'

import {API_KEY} from '../../constants'

import './index.css'

const IMAGE_URL = 'https://image.tmdb.org/t/p/w500'

const apiStatusConstants = {
  initial: 'INITIAL',
  inProgress: 'IN_PROGRESS',
  success: 'SUCCESS',
  failure: 'FAILURE',
}

const MovieDetails = () => {
  const {id} = useParams()

  const [movie, setMovie] = useState(null)
  const [cast, setCast] = useState([])
  const [apiStatus, setApiStatus] = useState(apiStatusConstants.initial)

  const getMovieDetails = async () => {
    const url = `https://api.themoviedb.org/3/movie/${id}?api_key=${API_KEY}&language=en-US`

    const response = await fetch(url)

    if (!response.ok) {
      throw new Error('Movie details request failed')
    }

    const data = await response.json()

    setMovie(data)
  }

  const getCastDetails = async () => {
    const url = `https://api.themoviedb.org/3/movie/${id}/credits?api_key=${API_KEY}&language=en-US`

    const response = await fetch(url)

    if (!response.ok) {
      throw new Error('Cast request failed')
    }

    const data = await response.json()

    setCast(data.cast || [])
  }

  const getMovieData = async () => {
    setApiStatus(apiStatusConstants.inProgress)

    try {
      await Promise.all([getMovieDetails(), getCastDetails()])

      setApiStatus(apiStatusConstants.success)
    } catch (error) {
      setApiStatus(apiStatusConstants.failure)
    }
  }

  useEffect(() => {
    getMovieData()
    // eslint-disable-next-line
  }, [id])

  const renderLoadingView = () => <h1>Loading...</h1>

  const renderSuccessView = () => (
    <>
      <div className="movie-details-container">
        <img
          src={
            movie.poster_path
              ? `${IMAGE_URL}${movie.poster_path}`
              : 'https://via.placeholder.com/500x750'
          }
          alt={movie.title}
          className="movie-image"
        />

        <div className="movie-info">
          <h1>{movie.title}</h1>

          <p>Rating: {movie.vote_average}</p>

          <p>Duration: {movie.runtime} minutes</p>

          <p>Release Date: {movie.release_date}</p>

          <p>Genre: {movie.genres?.map(item => item.name).join(', ')}</p>

          <p>{movie.overview}</p>
        </div>
      </div>

      <h2 className="cast-heading">Cast Details</h2>

      <div className="cast-grid">
        {cast.map(member => (
          <CastCard key={member.cast_id} cast={member} />
        ))}
      </div>
    </>
  )

  const renderFailureView = () => (
    <div>
      <h1>Something went wrong</h1>

      <button type="button" onClick={getMovieData}>
        Retry
      </button>
    </div>
  )

  const renderMovieDetailsView = () => {
    switch (apiStatus) {
      case apiStatusConstants.inProgress:
        return renderLoadingView()

      case apiStatusConstants.success:
        return renderSuccessView()

      case apiStatusConstants.failure:
        return renderFailureView()

      default:
        return null
    }
  }

  return (
    <>
      <Navbar />
      {renderMovieDetailsView()}
    </>
  )
}

export default MovieDetails
